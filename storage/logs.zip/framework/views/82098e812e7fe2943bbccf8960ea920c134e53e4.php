
<?php $__env->startSection('page-header'); ?>
                        <!-- PAGE-HEADER -->
                            <div><h1 class="page-title">Add Store</h1></div>
                        <!-- PAGE-HEADER END -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">

  <div class="card-body" id="add_space">
    <form action="<?php echo e(route("dashboard.vendorsettings.store")); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="row">
             <!--  <div class="col-md-2">
          <div class="form-group">Profile Image </label>
            <input type="file" class="form-control" id="exampleInputuname_1" name="profile_img" value="<?php echo e(($data['profile_img'])??''); ?>">
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="form-group">
             <?php if(isset($vendor->id)): ?>
            <img class="vendor_image" src="<?php echo e(url('')); ?>/images/vendor/settings/<?php echo e(($data['profile_img'])??''); ?>" style="height:100px;width:100px;" alt="logo" >
             <?php else: ?>
      
        <?php endif; ?>
          </div>
        </div>
         <div class="col-md-2">
          <div class="form-group">
            <label class="control-label ">Banner Image </label>
            <input type="file" class="form-control" id="exampleInputuname_1" name="banner_img" value="<?php echo e(($data['banner_img'])??''); ?>">
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-group">
             <?php if(isset($vendor->id)): ?>
            <img class="banner_img" src="<?php echo e(url('')); ?>/images/vendor/settings/<?php echo e(($data['banner_img'])??''); ?>" style="height:100px;width:100px;" alt="logo">
             <?php else: ?>
      
        <?php endif; ?>
          </div>
        </div> -->
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Store Name </label>
            <input type="text" name="first_name" class="form-control" value="<?php echo e(($data['first_name'])??''); ?>">
          </div>
        </div>
          <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Location</label>
            <input type="text" name="last_name" class="form-control" value="<?php echo e(($data['last_name'])??''); ?>">
          </div>
        </div>
      </div>
      <!-- <div class="row">
          <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Store Name </label>
            <input type="text" name="store_name" class="form-control" value="<?php echo e(($data['store_name'])??''); ?>">
          </div>
        </div>
      
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Store Address </label>
            <input type="text" name="store_url" class="form-control " value="<?php echo e(($data['store_url'])??''); ?>">
          </div>
        </div> -->
        <!-- <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Phone Number </label>
            <input type="number" name="phone_number" class="form-control " value="<?php echo e(($data['phone_number'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Email </label>
            <input type="email" class="form-control"  name="email" value="<?php echo e(($data['email'])??''); ?>">
          </div>
        </div>
        /span
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Username</label>
            <input type="text" class="form-control" name="user_name " value="<?php echo e(($data['first_name'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Password </label>
            <input type="number" class="form-control"  name="password" value="<?php echo e(($data['password'])??''); ?>">
          </div>
        </div> -->

        <button class="btn btn-success-light mt-3">Save & update</button>
      </div>
    </form>
     <form action="<?php echo e(route("dashboard.vendorsettings.store")); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <!-- <div class="row">
        <div class="col-md-6">
        <h4 class="mt-5">Address</h4> <hr>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Street-1</label>
            <input type="text" class="form-control"  name="street_1" value="<?php echo e(($data['street_1'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Street-2</label>
            <input type="text" class="form-control"  name="street_2" value="<?php echo e(($data['street_2'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">City</label>
            <input type="text" class="form-control"  name="city" value="<?php echo e(($data['city'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Zip</label>
            <input type="number" class="form-control"  name="zip" value="<?php echo e(($data['zip'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Country</label>
            <input type="text" class="form-control"  name="country" value="<?php echo e(($data['country'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">State</label>
            <input type="text" class="form-control"  name="state" value="<?php echo e(($data['state'])??''); ?>">
          </div>
        </div>
      </div></div>
      <div class="col-md-6">
        <h4 class="mt-5">Social links</h4><hr>
        <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Instagram</label>
            <input type="text" class="form-control"  name="instagram" value="<?php echo e(($data['instagram'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Youtube</label>
            <input type="text" class="form-control"  name="youtube" value="<?php echo e(($data['youtube'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Twitter</label>
            <input type="text" class="form-control"  name="twitter" value="<?php echo e(($data['twitter'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Linkedin</label>
            <input type="number" class="form-control"  name="linkedin" value="<?php echo e(($data['linkedin'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Facebook</label>
            <input type="text" class="form-control"  name="facebook" value="<?php echo e(($data['facebook'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Pinterest</label>
            <input type="text" class="form-control"  name="pinterest" value="<?php echo e(($data['pinterest'])??''); ?>">
          </div>
        </div>
      </div>
      
      </div>
       <button class="btn btn-success-light mt-3">Save & update</button>
       </div></form>
      <form action="<?php echo e(route("dashboard.vendorsettings.store")); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
       <h4 class="mt-5">Payment Options</h4>
       <hr>
      <div class="row">
            <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Account Name </label>
            <input type="text" class="form-control" name="account_name" value="<?php echo e(($data['account_name'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Account Number </label>
            <input type="number" class="form-control" name="account_number" value="<?php echo e(($data['account_number'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Bank Name </label>
            <input type="text" class="form-control" name="bank_name" value="<?php echo e(($data['bank_name'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">bank Number </label>
            <input type="text" class="form-control" name="bank_number" value="<?php echo e(($data['bank_number'])??''); ?>">
          </div>
        </div>
          <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Swift Code </label>
            <input type="text" class="form-control" name="swift_code" value="<?php echo e(($data['swift_code'])??''); ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label ">Routing Number </label>
            <input type="text" class="form-control" name="routing_number" value="<?php echo e(($data['routing_number'])??''); ?>">
          </div>
        </div>
          <div class="col-md-12">
            <label class="switch">
              <?php if(isset($data['selling'])): ?>
              <input type="checkbox" id="selling" name="selling" <?php echo e(( $data['selling'] == 1)?'checked':''); ?>>
              <?php endif; ?>
              <span class="slider round"></span>
            </label>
        
        <label for="scales">Enable Selling</label>
      </div>
        <div class="col-md-12">
            <label class="switch">
               <?php if(isset($data['product_publish'])): ?>
              <input type="checkbox" id="product_publish" name="product_publish" <?php echo e(($data['product_publish'] == 1)?'checked':''); ?>>
               <?php endif; ?>
              <span class="slider round"></span>
            </label>
        
        <label for="scales">Publish Product direct</label>
      </div>
        <div class="col-md-12">
           <label class="switch">
            <?php if(isset($data['feature_vendor'])): ?>
              <input type="checkbox" id="feature_vendor" name="feature_vendor" <?php echo e(($data['feature_vendor'] == 1)?'checked':''); ?>>
               <?php endif; ?>
              <span class="slider round"></span>
            </label>
       
        <label for="scales">Make feature vendor</label>
      </div>
       <div class="col-md-12">
        <label class="switch">
          <?php if(isset($data['notify'])): ?>
             <input type="checkbox" id="notify" name="notify" <?php echo e(($data['notify'] == 1)?'checked':''); ?>>
              <?php endif; ?>
              <span class="slider round"></span>
            </label>
        
        <label for="scales">Send the vendor an email About their account</label>
      </div>
      </div> -->
    

    <!-- <div class="form-actions" id="add_space"> -->
      <!-- <button class="btn btn-success-light mt-3">Save & update</button> -->
    </div>
    </div>
    </div>
  </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vertical-menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\popkart\resources\views/admin/vendor-setting.blade.php ENDPATH**/ ?>