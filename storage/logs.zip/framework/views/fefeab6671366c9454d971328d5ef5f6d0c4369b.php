<!--APP-SIDEBAR-->

<div class="app-sidebar__overlay" data-toggle="sidebar"></div>

                <aside class="app-sidebar">

                    <div class="side-header">

                         <img width="70%" src="<?php echo e(asset('assets/images/popkart.png')); ?>" alt="logo">

                        <a aria-label="Hide Sidebar" class="app-sidebar__toggle ml-auto" data-toggle="sidebar" href="#"></a><!-- sidebar-toggle-->

                    </div>

                    <div class="app-sidebar__user">

                        <div class="dropdown user-pro-body text-center">

                            <div class="user-pic">

                                <img src="<?php echo e(asset('assets/images/icon.png')); ?>" alt="user-img" class="avatar-xl rounded-circle">

                            </div>

                            <div class="user-info">

                                <h6 class=" mb-0 text-dark"><?php echo e(ucfirst(Auth::user()->first_name)); ?></h6>
                                <span class="text-muted app-sidebar__user-name text-sm"><?php echo e(ucfirst(Auth::user()->roles->first()->title)); ?></span>

                            </div>

                        </div>

                    </div>

                    <div class="sidebar-navs d-flex justify-content-center">

                        <ul class="nav  nav-pills-circle text-center">

                            <li class="nav-item" data-toggle="tooltip" data-placement="top" title="Settings">

                                <a href="<?php echo e(route('dashboard.users.edit', Auth::id())); ?>" class="nav-link text-center m-2">

                                    <i class="fe fe-settings"></i>

                                </a>

                            </li>

                            <!-- <li class="nav-item" data-toggle="tooltip" data-placement="top" title="Chat">

                                <a class="nav-link text-center m-2">

                                    <i class="fe fe-mail"></i>

                                </a>

                            </li> -->

                            <!-- <li class="nav-item" data-toggle="tooltip" data-placement="top" title="Followers">

                                <a class="nav-link text-center m-2">

                                    <i class="fe fe-user"></i>

                                </a>

                            </li> -->



           

                            <li class="nav-item" data-toggle="tooltip" data-placement="top" title="Logout">

                                <a href="<?php echo e(route('logout')); ?>" class="nav-link text-center m-2"  onclick="event.preventDefault();

                                                     document.getElementById('logout-form').submit();">

                                    <i class="fe fe-power"></i>

                                </a>

                                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">

                                        <?php echo csrf_field(); ?>

                                    </form>

                            </li>

                        </ul>

                    </div>

                    <ul class="side-menu mt-3" >

                        

                        <li class="slide">

                            <a class="side-menu__item" data-toggle="slide" href="<?php echo e(url('/' . $page='home')); ?>"><i class="side-menu__icon ti-home"></i><span class="side-menu__label">Dashboard</span></a>

                           <!--  <ul class="slide-menu">

                                <li><a href="<?php echo e(url('/' . $page='home')); ?>" class="slide-item">Home</a></li> -->

                                <!-- <li class="sub-slide">

                                    <a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Marketing</span><i class="sub-angle fa fa-angle-right"></i></a>

                                    <ul class="sub-slide-menu">

                                        <li><a class="sub-slide-item" href="<?php echo e(route('dashboard.dashboard.index')); ?>">Rewards</a></li>

                                    </ul>

                                </li>

                                <li><a href="<?php echo e(url('/' . $page='index3')); ?>" class="slide-item">Service</a></li>

                                <li><a href="<?php echo e(url('/' . $page='index4')); ?>" class="slide-item">Finance</a></li>

                                <li><a href="<?php echo e(url('/' . $page='index2')); ?>" class="slide-item">Operation</a></li>

                                <li><a href="<?php echo e(url('/' . $page='index5')); ?>" class="slide-item">Support</a></li>

                                <li><a href="<?php echo e(url('/' . $page='index3')); ?>" class="slide-item">Delivery</a></li>

                                <li><a href="<?php echo e(url('/' . $page='index4')); ?>" class="slide-item">Party</a></li>

                                <li><a href="<?php echo e(url('/' . $page='index5')); ?>" class="slide-item">IT</a></li>

                            </ul>

                        </li> -->

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_management')): ?>

                        <li class="slide">

                            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-package"></i><span class="side-menu__label">Items</span><i class="angle fa fa-angle-right"></i></a>

                            <ul class="slide-menu">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_access')): ?>

                                <li><a href="<?php echo e(route('dashboard.product.index')); ?>" class="slide-item">All Item</a></li>

                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_access')): ?>

                                <li><a href="<?php echo e(route('dashboard.category.index')); ?>" class="slide-item">Category</a></li>

                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attribute_access')): ?>

                                <!-- <li><a href="<?php echo e(route('dashboard.attribute.index')); ?>" class="slide-item">Attribute</a></li> -->

                             <!--    <li><a href="<?php echo e(route('dashboard.attribute-value.index')); ?>" class="slide-item">Attribute Value</a></li> -->

                                <?php endif; ?>

                            </ul>

                        </li>

                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_access')): ?>

                      <!--   <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.order.index')); ?>"><i class="side-menu__icon fe fe-shopping-cart"></i><span class="side-menu__label">Order</span></a>

                        </li> -->

                        <!--  <li class="slide">

                            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-shopping-cart"></i><span class="side-menu__label">Order</span><i class="angle fa fa-angle-right"></i></a>

                            <ul class="slide-menu">

                                <li><a href="<?php echo e(route('dashboard.order.index')); ?>" class="slide-item">Ordered Items</a></li>

                                <li><a href="<?php echo e(route('dashboard.delivered-orders')); ?>" class="slide-item">Delivery Items</a></li>

                                

                            </ul>

                        </li> -->

                         <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('page_access')): ?>

                        <!-- <li class="slide">

                            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-book-open"></i><span class="side-menu__label">Pages</span><i class="angle fa fa-angle-right"></i></a>

                            <ul class="slide-menu">

                                <li><a href="<?php echo e(route('dashboard.homepage.edit',1)); ?>" class="slide-item">Home</a></li>

                                <li><a href="<?php echo e(route('dashboard.pages.index')); ?>" class="slide-item">Page List</a></li>

                                <li><a href="<?php echo e(route('dashboard.pages.create')); ?>" class="slide-item">Add New </a></li>

                            </ul>

                        </li> -->

                        <?php endif; ?>

                        <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.pakage.index')); ?>"><i class="side-menu__icon icon icon-credit-card"></i><span class="side-menu__label">Subcriptions</span></a>

                        </li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_access')): ?>

                         <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.coupon.index')); ?>"><i class="side-menu__icon icon icon-present"></i><span class="side-menu__label">Coupon</span></a>

                        </li>

                        <?php endif; ?>
                         <li>

                              <a class="side-menu__item" href="<?php echo e(route('dashboard.healthtips.index')); ?>"><i class="side-menu__icon icon fe fe-heart"></i><span class="side-menu__label">Health Tips</span></a>

                         </li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('testimonal_access')): ?>

                        <!-- <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.testimonials.index')); ?>"><i class="side-menu__icon icon icon-trophy"></i><span class="side-menu__label">Testimonal</span></a>

                        </li> -->
                        <?php endif; ?>
                      
                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu_access')): ?>
                         <!-- <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.menus.index')); ?>"><i class="side-menu__icon icon icon-list"></i><span class="side-menu__label">Menus</span></a>

                        </li> -->
                         <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('log_access')): ?>

                        <!--   <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.logActivity')); ?>"><i class="side-menu__icon icon icon-clock"></i><span class="side-menu__label"> Users Logs</span></a>

                        </li> -->

                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_access')): ?>

                       <!--  <li>

                            <a class="side-menu__item" href="#"><i class="side-menu__icon fe fe-clipboard"></i><span class="side-menu__label">Reports</span></a>

                        </li> -->

                        <?php endif; ?>

                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('widgets_access')): ?>

                        <!-- <li>

                            <a class="side-menu__item" href="#"><i class="side-menu__icon ti-package"></i><span class="side-menu__label">Widgets</span></a>

                        </li> -->

                        <?php endif; ?>

                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gift_card_access')): ?>
                          <li class="slide">

                            <a class="side-menu__item" data-toggle="slide" href="<?php echo e(route('dashboard.gift-card.index')); ?>"><i class="side-menu__icon icon icon-trophy"></i><span class="side-menu__label">Rewards</span></a>

                            <!-- <ul class="slide-menu">

                                <li><a href="<?php echo e(route('dashboard.gift-card.create')); ?>" class="slide-item">Add New </a></li>

                                <li><a href="<?php echo e(route('dashboard.gift-card.index')); ?>" class="slide-item">Reward List</a></li>

                                <li><a href="<?php echo e(route('dashboard.card-deatils')); ?>" class="slide-item">Details of Gift Card</a></li>

                            </ul> -->

                        </li>
                         <?php endif; ?>

                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reviews_access')): ?>

                       <!--  <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.review.index')); ?>"><i class="side-menu__icon icon icon-star"></i><span class="side-menu__label">Reviews</span></a>

                        </li> -->

                         <?php endif; ?>

                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vuser_access')): ?>

                         

                         <?php endif; ?>

                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('store_settings')): ?>
                            <li class="slide">

                            <a class="side-menu__item" data-toggle="slide" href="<?php echo e(route('dashboard.vendorsettings.index')); ?>"><i class="side-menu__icon fe fe-shopping-bag"></i><span class="side-menu__label">Stores</span></a>

                            <!-- <ul class="slide-menu">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list_vendor')): ?>
                                <li><a href="<?php echo e(route('dashboard.vendorsettings.index')); ?>" class="slide-item">Vendor List</a></li>
                            <?php endif; ?>

                              
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general_setting')): ?>
                                <li class="sub-slide">
                                    <a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Setting</span><i class="sub-angle fa fa-angle-right"></i></a>
                                    <ul class="sub-slide-menu">
                                        <li><a class="sub-slide-item" href="<?php echo e(route('dashboard.general-setting.index')); ?>">General setting</a></li>
                                    </ul>
                                </li>
                                <?php endif; ?>
                                    <li><a href="<?php echo e(route('dashboard.withdrow.index')); ?>" class="slide-item">Withdrawal Request</a></li>
                                <?php if(Auth::user()->roles->first()->title == "Vendor"): ?>
                                    <li><a href="<?php echo e(route('dashboard.withdrow.create')); ?>" class="slide-item">Withdraw</a></li>
                                <?php endif; ?>

                            </ul> -->

                        </li>
                         <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_settings')): ?>
                        <!-- <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.vendor-setting')); ?>"><i class="side-menu__icon icon icon-settings"></i><span class="side-menu__label">Settings</span></a>

                        </li> -->
                         <?php endif; ?>

                         <!-- <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.store.index')); ?>"><i class="side-menu__icon fe fe-shopping-bag"></i><span class="side-menu__label">Stores</span></a>

                        </li> -->

                        <li>

                            <a class="side-menu__item" href="<?php echo e(route('dashboard.list.index')); ?>"><i class="side-menu__icon fe fe-list"></i><span class="side-menu__label">Grocery List Creation</span></a>

                        </li>

                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>

                           <li class="slide">

                                <a class="side-menu__item" data-toggle="slide" href="#"> <i class="side-menu__icon fe fe-user"></i><span class="side-menu__label">Users Management</span><i class="angle fa fa-angle-right"></i></a>

                                <ul class="slide-menu">

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>

                                    <li><a href="<?php echo e(route('dashboard.roles.index')); ?>" class="slide-item">User Roles</a></li>

                                     <?php endif; ?>

                                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>

                                    <li><a href="<?php echo e(route('dashboard.permissions.index')); ?>" class="slide-item">Role Permissions</a></li>

                                     <?php endif; ?>

                                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>

                                    <li><a href="<?php echo e(route('dashboard.users.index')); ?>" class="slide-item">User</a></li>

                                     <?php endif; ?>

                                </ul>

                           </li>

                         <?php endif; ?>

                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('web_settings')): ?>

                          <!-- li class="slide">

                            <a class="side-menu__item" data-toggle="slide" href="#"><i class="side-menu__icon fe fe-settings"></i><span class="side-menu__label"> Web Settings</span><i class="angle fa fa-angle-right"></i></a>

                            <ul class="slide-menu">

                               
                               
                                <li><a href="<?php echo e(route('dashboard.mail.index')); ?>" class="slide-item">Mail Template</a></li>

                                <li><a href="<?php echo e(route('dashboard.tax.index')); ?>" class="slide-item">Tax Settings</a></li>

                                <li><a href="<?php echo e(route('dashboard.settings.index')); ?>" class="slide-item">Commision</a></li>

                                <li><a href="<?php echo e(route('dashboard.settings.index')); ?>" class="slide-item">Settings</a></li>

                            </ul>

                        </li> -->

                        <?php endif; ?> 

                      

                        </li>

                           

                    </ul>

                </aside>

<!--/APP-SIDEBAR-->

<?php /**PATH C:\xampp\htdocs\popkart\resources\views/layouts/vertical-menu/app-sidebar.blade.php ENDPATH**/ ?>