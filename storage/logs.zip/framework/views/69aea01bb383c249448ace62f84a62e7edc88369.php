
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/select2/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
                        <!-- PAGE-HEADER -->
                            <div>
                             
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Logs</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">List</li>
                                </ol>
                            </div>
                        
                        <!-- PAGE-HEADER END -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
                        <!-- ROW-1 OPEN-->
                            <!-- ROW-1 OPEN -->
                            <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="card">
                                <div class="addnew-ele">
                               
                            </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table id="example" class="table table-striped table-bordered text-nowrap w-100">
                                                <thead>
                                                   <tr>
														<th>No</th>
														<th>Subject</th>
														<th>URL</th>
														<th>Method</th>
														<th>Ip</th>
														<th width="300px">User Agent</th>
														<th>User Id</th>
														<th>Action</th>
													</tr>
                                                </thead>
                                                <tbody>
                                         
                                                    <tr>
                                                     
                                                         <?php if(count($logs)>0): ?>
															<?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<tr>
																<td><?php echo e(++$key); ?></td>
																<td><?php echo e($log->subject); ?></td>
																<td class="text-success"><?php echo e($log->url); ?></td>
																<td><label class="label label-info"><?php echo e($log->method); ?></label></td>
																<td class="text-warning"><?php echo e($log->ip); ?></td>
																<td class="text-danger"><?php echo e($log->agent); ?></td>
																<td><?php echo e($log->user_id); ?></td>
																<td>
																 <form action="<?php echo e(route('dashboard.logsdelete', $log->id)); ?>" method="POST" onsubmit="return confirm('Are you sure');" style="display: inline-block;">
                                                                        <input type="hidden" name="_method" value="DELETE">
                                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                        <button type="submit" class="btn btn-sm btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                                                        	<i class="fa fa-trash"></i>
                                                                        </button>
                                                                    </form>
                                                                </td>
															</tr>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php endif; ?>
                                                    </tr>
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- TABLE WRAPPER -->
                                </div>
                                <!-- SECTION WRAPPER -->
                            </div>
                        </div>
                        <!-- ROW-1 CLOSED -->               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/datatable.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
 
<!-- 
<div class="container">
	<h1>Log Activity Lists</h1>
	<table class="table table-bordered">
		<tr>
			<th>No</th>
			<th>Subject</th>
			<th>URL</th>
			<th>Method</th>
			<th>Ip</th>
			<th width="300px">User Agent</th>
			<th>User Id</th>
			<th>Action</th>
		</tr>
		<?php if($logs->count()): ?>
			<?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e(++$key); ?></td>
				<td><?php echo e($log->subject); ?></td>
				<td class="text-success"><?php echo e($log->url); ?></td>
				<td><label class="label label-info"><?php echo e($log->method); ?></label></td>
				<td class="text-warning"><?php echo e($log->ip); ?></td>
				<td class="text-danger"><?php echo e($log->agent); ?></td>
				<td><?php echo e($log->user_id); ?></td>
				<td><button class="btn btn-danger btn-sm">Delete</button></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</table>
</div>
 -->

<?php echo $__env->make('layouts.vertical-menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\popkart\resources\views/logActivity.blade.php ENDPATH**/ ?>