
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/select2/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
                        <!-- PAGE-HEADER -->
                            <div>
                                <h1 class="page-title"><?php echo e($title); ?></h1>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">testimonials</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">List</li>
                                </ol>
                            </div>
                        
                        <!-- PAGE-HEADER END -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
                        <!-- ROW-1 OPEN-->
                            <!-- ROW-1 OPEN -->
                            <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="card">
                                <div class="addnew-ele">
                                <a href="<?php echo e(route('dashboard.testimonials.create')); ?>" class="btn btn-info-light ">
                                    <?php echo e($buton_name); ?>

                                </a>
                            </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <div class="paging-section">
                                            <form method="get"  >
                                                    <h6>show</h6>
                                                    <select id="pagination" name="paginate">
                                                        <option value="10" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 10) ? 'selected':''); ?>>10</option>
                                                        <option value="20" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 20) ? 'selected':''); ?>>20</option>
                                                        <option value="30" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 30) ? 'selected':''); ?>>30</option>
                                                        <option value="50" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 40) ? 'selected':''); ?>>30</option>
                                                   <?php if(isset($_GET['page'])): ?><input type="hidden" name="page" value="<?php echo e($_GET['page']); ?>"><?php endif; ?>
                                                   <input type="submit" name="" style="display:none;">
                                               </form>
                                                <div id="pagination"><?php echo e($testimonials->links()); ?></div>
                                               </div>
                                            <table id="" class="table table-striped table-bordered text-nowrap w-100">
                                                
                                                <thead id="t-head">
                                                    <tr>
                                                        <th class="wd-10p">id</th>
                                                        <th class="wd-15p">Title</th>
                                                        <th class="wd-15p">Image</th>
                                                        <th class="wd-15p">Customer name</th>
                                                        <th class="wd-15p">Designation</th>
                                                        <th class="wd-15p">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php if(count($testimonials)>0): ?>
                                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($item->id ?? ''); ?></td>
                                                        <td><?php echo e($item->title ?? ''); ?></td>
                                                        <td><img src="<?php echo e(url('testimonials').'/'.$item->image); ?>" alt="" style="height:50px"></td>
                                                        <td><?php echo e($item->customer_name ?? ''); ?></td>
                                                        <td><?php echo e($item->designation ?? ''); ?></td>
                                                        <td>
                                                               
                                                                 <a class="btn btn-sm btn-secondary" href="<?php echo e(route('dashboard.testimonials.edit', $item->id)); ?>"><i class="fa fa-edit"></i> </a>
                                                                 
                                                               
                                                                    <form action="<?php echo e(route('dashboard.testimonials.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Are you sure');" style="display: inline-block;">
                                                                        <input type="hidden" name="_method" value="DELETE">
                                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                        <button type="submit" class="btn btn-sm btn-danger" value="<?php echo e(trans('global.delete')); ?>"><i class="fa fa-trash"></i></button>
                                                                    </form>
                                                               
                                                            </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                        <div id="pagination"><?php echo e($testimonials->links()); ?></div>
                                    </div>
                                    <!-- TABLE WRAPPER -->
                                </div>
                                <!-- SECTION WRAPPER -->
                            </div>
                        </div>
                        <!-- ROW-1 CLOSED -->               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/datatable.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>

<script type="text/javascript">
$(document).ready(function() {
  $('#pagination').on('change', function() {
    var $form = $(this).closest('form');
    //$form.submit();
    $form.find('input[type=submit]').click();
    console.log( $form);
  });
});

//     $("select").change(function() {
//      var paging = this.value;
//      $.ajaxSetup({
//     headers: {
//         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//     }
// });

//     $.ajax({
       
//         url: '<?php echo e(route("dashboard.category-pagination")); ?>', 
//         type: 'POST',
//         headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
//         data: {option : paging},
        
//         success: function(response) {
//               $('tbody').html( response.html);
//         }
//     });
// });

</script>

<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.vertical-menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\popkart\resources\views/admin/testimonials/index.blade.php ENDPATH**/ ?>