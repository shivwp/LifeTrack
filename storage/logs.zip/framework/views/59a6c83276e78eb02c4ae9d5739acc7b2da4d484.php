		<!-- FAVICON -->
		<!-- <link rel="icon"  type="image/png" href="http://wasilonline.eoxysitsolution.com/dashboard/assets/images/brand/favicon-wasil.jpg"> -->

		<!-- TITLE -->
		<title>popkart.com</title>

		<!-- BOOTSTRAP CSS -->
		<link href="<?php echo e(URL::asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
		<!-- MDBootstrap Datatables  -->
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

		<!-- STYLE CSS -->
		<link href="<?php echo e(URL::asset('public/assets/css/custom.css')); ?>" rel="stylesheet"/>
		<link href="<?php echo e(URL::asset('assets/css/style.css')); ?>" rel="stylesheet"/>
		<link href="<?php echo e(URL::asset('assets/css/custom.css')); ?>" rel="stylesheet"/>
		<link href="<?php echo e(URL::asset('assets/css/skin-modes.css')); ?>" rel="stylesheet"/>
		<link href="<?php echo e(URL::asset('assets/css/dark-style.css')); ?>" rel="stylesheet"/>
		

		<link href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css" rel="stylesheet">


		<!--C3 CHARTS CSS -->
		<link href="<?php echo e(URL::asset('assets/plugins/charts-c3/c3-chart.css')); ?>" rel="stylesheet"/>

		<!-- P-scroll bar css-->
		<link href="<?php echo e(URL::asset('assets/plugins/p-scroll/perfect-scrollbar.css')); ?>" rel="stylesheet" />

		<!--- FONT-ICONS CSS -->
		<link href="<?php echo e(URL::asset('assets/plugins/icons/icons.css')); ?>" rel="stylesheet"/>

        <?php echo $__env->yieldContent('css'); ?>

        <!-- SIDE-MENU CSS -->
        <link href="<?php echo e(URL::asset('assets/css/sidemenu.css')); ?>" rel="stylesheet"/>

		<!-- SIDEBAR CSS -->
		<link href="<?php echo e(URL::asset('assets/plugins/sidebar/sidebar.css')); ?>" rel="stylesheet"/>

		<!-- COLOR SKIN CSS -->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(URL::asset('assets/colors/color1.css')); ?>" />


<?php /**PATH C:\xampp\htdocs\popkart\resources\views/layouts/vertical-menu/head.blade.php ENDPATH**/ ?>