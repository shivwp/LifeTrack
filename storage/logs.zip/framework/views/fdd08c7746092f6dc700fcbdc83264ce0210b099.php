
test
<?php /**PATH C:\xampp\htdocs\popkart\resources\views/mails/register.blade.php ENDPATH**/ ?>