<h1>User Details</h1>

<h4>User  First Name ..<?php echo e($first_name); ?></h4>
<h4>User  First Name ..<?php echo e($last_name); ?></h4>
<h5>User Registered Email id is..<?php echo e($email); ?></h5>

<h1>Thanks <h1>
    <h3><?php echo e($first_name); ?></h3><?php /**PATH C:\xampp\htdocs\popkart\resources\views/admin\users\mail.blade.php ENDPATH**/ ?>