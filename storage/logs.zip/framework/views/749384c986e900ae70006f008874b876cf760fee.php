
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(URL::asset('assets/plugins/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/wysiwyag/richtext.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
                        <!-- PAGE-HEADER -->
                            <div>
                                <h1 class="page-title"><?php echo e($title); ?></h1>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.menus.index')); ?>">Menu</a></li>
                                      <?php if(isset($menu->id)): ?>
                                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                                    <?php else: ?>
                                        <li class="breadcrumb-item active" aria-current="page">Add</li>
                                    <?php endif; ?>
                                </ol>
                            </div>
                        
                        <!-- PAGE-HEADER END -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
             <div class="card">
                                <form  method="post" action="<?php echo e(route('dashboard.menus.store')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        <form  method="post" action="<?php echo e(route('dashboard.menus.store')); ?>" enctype="multipart/form-data">
                                      
                                            <div class="row">
                                                <input type="hidden" name="id" value="<?php echo e(isset($menu) ? $menu->id : ''); ?>">
                                               
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="form-label">Title</label>
                                                        <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo e(old('title', isset($menu) ? $menu->title : '')); ?>" required>
                                                    </div>
                                                     <div class="form-group">
                                                        <label class="form-label">url</label>
                                                        <input type="text" class="form-control" name="url" placeholder="Title" value="<?php echo e(old('url', isset($menu) ? $menu->url : '')); ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="form-label">Position</label>
                                                        <input type="text" class="form-control" name="position" placeholder="Title" value="<?php echo e(old('position', isset($menu) ? $menu->position : '')); ?>" required>
                                                    </div>
                                                    
                                                  
                                                </div>
                                                
                                            </div>
                                       
                                        <?php if(isset($menu->id)): ?>
                                            <button class="btn btn-success-light mt-3 " type="submit">Update</button>
                                        <?php else: ?>
                                            <button class="btn btn-success-light mt-3 " type="submit">Save</button>
                                        <?php endif; ?>
                                    </div>

                                     </form>
                                    
                                </div>              
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('assets/plugins/chart/Chart.bundle.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/chart/utils.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/wysiwyag/jquery.richtext.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/wysiwyag/wysiwyag.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/summernote/summernote-bs4.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical-menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\popkart\resources\views/admin/menu/add.blade.php ENDPATH**/ ?>