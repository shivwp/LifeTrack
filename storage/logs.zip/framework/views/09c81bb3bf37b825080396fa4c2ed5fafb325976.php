
<?php $__env->startSection('css'); ?>
<style>
.paging-section {
    display: flex!important;
    justify-content: flex-start !important;
    margin: 13px 5px;
}
.get-filter{
    margin:0px 20px
}
</style>
<link href="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/select2/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
                        <!-- PAGE-HEADER -->
                            <div>
                                <h1 class="page-title"><?php echo e($title); ?></h1>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Coupon</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">List</li>
                                </ol>
                            </div>
                        
                        <!-- PAGE-HEADER END -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
                        <!-- ROW-1 OPEN-->
                            <!-- ROW-1 OPEN -->
                            <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="card">
                                <div class="addnew-ele">
                              
                            </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <div class="paging-section">
                                            <form method="get"  >
                                                    <h6>show</h6>
                                                    <select id="pagination" name="paginate" class="form-control select2">
                                                        <option value="10" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 10) ? 'selected':''); ?>>10</option>
                                                        <option value="20" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 20) ? 'selected':''); ?>>20</option>
                                                        <option value="30" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 30) ? 'selected':''); ?>>30</option>
                                                        <option value="50" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 40) ? 'selected':''); ?>>30</option>
                                                   <?php if(isset($_GET['page'])): ?><input type="hidden" name="page" value="<?php echo e($_GET['page']); ?>"><?php endif; ?>
                                                   <input type="submit" name="" style="display:none;">
                                               </form>
                                            <form method="get" class="get-filter" id="filter-submit">
                                                    <h6>Status Filter</h6>
                                                    <select id="filter-status" name="status" class="form-control select2">
                                                    <option value="">all</option>
                                                        <option value="1" <?php echo e((request()->get('status') == '1') ? 'selected' : ''); ?>>Approved</option>
                                                        <option value="2"<?php echo e((request()->get('status') == '2') ? 'selected' : ''); ?>>Rejected</option>
                                                        <option value="0" <?php echo e((request()->get('status') == '0') ? 'selected' : ''); ?>>Pending</option>
                                                    </select>
                                            </form>
                                                <div id="pagination"><?php echo e($withdrow->links()); ?></div>
                                               </div>
                                            <table id="" class="table table-striped table-bordered text-nowrap w-100">
                                                <thead>
                                                    <tr>
                                                        <th class="wd-15p">Id</th>
                                                        <th class="wd-15p">Vendor</th>
                                                        <th class="wd-15p">Amount</th>
                                                        <th class="wd-15p">Status</th>
                                                        <th class="wd-15p">Method</th>
                                                        <th class="wd-15p">Note</th>
                                                        <?php if(Auth::user()->roles->first()->title == "Admin"): ?>
                                                        <th class="wd-15p">Action</th>
                                                        <?php endif; ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php if(count($withdrow)>0): ?>
                                                    <?php $__currentLoopData = $withdrow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($item->id ?? ''); ?></td>
                                                            <td><?php echo e($item->vendor->first_name ?? ''); ?></td>
                                                            <td><?php echo e($item->amount ?? ''); ?></td>
                                                            <td>
                                                            <?php if($item->status == 0): ?>
                                                         <span class="tag tag-blue">pending</span>
                                                         <?php elseif($item->status == 1): ?>
                                                         <span class="tag tag-azure">approved</span>
                                                         <?php else: ?>
                                                         <span class="tag tag-indigo">rejected</span>
                                                         <?php endif; ?>
                                                            </td>
                                                            <td><?php echo e($item->method ?? ''); ?></td>
                                                            <td><?php echo e($item->note ?? ''); ?></td>
                                                            <?php if(Auth::user()->roles->first()->title == "Admin"): ?>
                                                            <td>
                                                            <button  type="button" class="btn btn-sm btn-secondary accept" data-toggle="modal" data-target="#exampleModal" value="<?php echo e($item->id); ?>" >
                                                            <i class="fa fa-check"></i>
                                                            </button>
                                                            <button  type="button" class="btn btn-sm btn-secondary reject" data-toggle="modal" data-target="#exampleModal1" value="<?php echo e($item->id); ?>" >
                                                            <i class="fa fa-ban"></i>
                                                            </button>
                                                                
                                                                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_delete')): ?>
                                                                    <form action="<?php echo e(route('dashboard.tax.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Are you sure');" style="display: inline-block;">
                                                                        <input type="hidden" name="_method" value="DELETE">
                                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                        <button type="submit" class="btn btn-sm btn-danger" value=""><i class="fa fa-trash"></i></button>
                                                                    </form>
                                                                    <?php endif; ?>
                                                                   
                                                               
                                                            </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                          <div id="pagination"><?php echo e($withdrow->links()); ?></div>
                                    </div>
                                    <!-- TABLE WRAPPER -->
                                </div>
                                <!-- SECTION WRAPPER -->
                            </div>
                        </div>
                        <!-- ROW-1 CLOSED -->     
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <form action ="<?php echo e(route('dashboard.approve-request')); ?>"> 
        <input type="hidden" class="form-control withdrowid"  name="id" value="">
      <div class="modal-body">
        <label>Add Comment</label>
        <textarea class="form-control" name="comment" value=""></textarea>
      </div>
      <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div> 
<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <form action ="<?php echo e(route('dashboard.reject-request')); ?>"> 
        <input type="hidden" class="form-control withdrowrejectid"  name="id" value="">
      <div class="modal-body">
        <label>Add Comment</label>
        <textarea class="form-control" name="comment" value=""></textarea>
      </div>
      <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>                   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/datatable.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
  $('#pagination').on('change', function() {
    var $form = $(this).closest('form');
    //$form.submit();
    $form.find('input[type=submit]').click();
    console.log( $form);
  });
  $('.accept').on('click', function() {
      var accept = $(this).val();

      $('.withdrowid').val(accept);

  }); 
  $('.reject').on('click', function() {
      var reject = $(this).val();

      $('.withdrowrejectid').val(reject);

  });
  $('#filter-status').on('change', function() {
        $('#filter-submit').submit();
    });       
});
</script>
<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('layouts.vertical-menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\popkart\resources\views/admin/withdrow/index.blade.php ENDPATH**/ ?>