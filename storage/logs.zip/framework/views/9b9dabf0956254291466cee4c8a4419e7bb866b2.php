
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(URL::asset('assets/plugins/single-page/css/main.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- BACKGROUND-IMAGE -->
        <div class="login-img">

            <!-- GLOABAL LOADER -->
            <div id="global-loader">
                <img src="<?php echo e(URL::asset('assets/images/loader.svg')); ?>" class="loader-img" alt="Loader">
            </div>
            <!-- /GLOABAL LOADER -->

            <!-- PAGE -->
            
            <div class="page">
                <div class="">
                    <!-- CONTAINER OPEN -->
                    <div class="col col-login mx-auto">
                        <div class="text-center">
                            <!-- <img src="<?php echo e(URL::asset('assets/images/brand/logo.png')); ?>" class="header-brand-img" alt=""> -->
                        </div>
                    </div>
                    <div class="container-login100">
                        <div class="wrap-login100 p-6">
                            <form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
                                 <?php echo csrf_field(); ?>
                                <span class="login100-form-title">
                                    Login
                                </span>
                                    <?php if(session('error')): ?>
                                     <div class="alert alert-danger text-center h5">
                                         <?php echo e(session('error')); ?>

                                     </div>
                                  <?php endif; ?>
                                <div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
                                    <input class="input100" type="text" name="email" placeholder="Email">
                                    <span class="focus-input100"></span>
                                    <span class="symbol-input100">
                                        <i class="zmdi zmdi-email" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="wrap-input100 validate-input" data-validate = "Password is required">
                                    <input class="input100" type="password" name="password" placeholder="Password">
                                    <span class="focus-input100"></span>
                                    <span class="symbol-input100">
                                        <i class="zmdi zmdi-lock" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="text-right pt-1">
                                    <p class="mb-0"><a href="<?php echo e(route('password.request')); ?>" class="text-primary ml-1">Forgot Password?</a></p>
                                </div>
                                <div class="container-login100-form-btn">
                                    <button class="login100-form-btn btn-primary">Login</button>
                                </div>
                               
                                
                            </form>
                        </div>
                    </div>
                    <!-- CONTAINER CLOSED -->
                </div>
            </div>
            <!-- End PAGE -->

        </div>
        <!-- BACKGROUND-IMAGE CLOSED -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical-menu.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\popkart\resources\views/auth/login.blade.php ENDPATH**/ ?>