
<?php $__env->startSection('css'); ?>
<style type="text/css">
    .permission-span{
          max-width: 100%;
    width: 75%;
    text-align: justify;
    line-height: 30px;
    }
</style>
<link href="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/select2/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
                        <!-- PAGE-HEADER -->
                            <div>
                                <h1 class="page-title"><?php echo e($title); ?></h1>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Roles</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">List</li>
                                </ol>
                            </div>
                        
                        <!-- PAGE-HEADER END -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
                        <!-- ROW-1 OPEN-->
                            <!-- ROW-1 OPEN -->
                            <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="card">
                                <div class="addnew-ele">
                                <a href="<?php echo e(route('dashboard.roles.create')); ?>" class="btn btn-info-light ">
                                    <?php echo e($buton_name); ?>

                                </a>
                            </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <div class="paging-section">
                                            <form method="get"  >
                                                    <h6>show</h6>
                                                    <select id="pagination" name="paginate">
                                                        <option value="10" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 10) ? 'selected':''); ?>>10</option>
                                                        <option value="20" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 20) ? 'selected':''); ?>>20</option>
                                                        <option value="30" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 30) ? 'selected':''); ?>>30</option>
                                                        <option value="50" <?php echo e(isset($_GET['paginate']) && ($_GET['paginate'] == 40) ? 'selected':''); ?>>30</option>
                                                   <?php if(isset($_GET['page'])): ?><input type="hidden" name="page" value="<?php echo e($_GET['page']); ?>"><?php endif; ?>
                                                   <input type="submit" name="" style="display:none;">
                                               </form>
                                                <div id="pagination"><?php echo e($roles->links()); ?></div>
                                               </div>
                                            <table id="page-length-option" class="table table-striped table-bordered w-100">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th class="wd-15p">Title</th>
                                                        <th class="wd-15p">Permissions</th>
                                                        <th class="wd-15p">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php if(count($roles)>0): ?>
                                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($item->id ?? ''); ?></td>
                                                            <td><?php echo e($item->title ?? ''); ?></td>
                                                            <td class="permission-span">
                                                            <?php $__currentLoopData = $item->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="badge badge-info"><?php echo e($item1->title); ?></span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                
                                                                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_edit')): ?>
                                                                 <a class="btn btn-sm btn-secondary" href="<?php echo e(route('dashboard.roles.edit', $item->id)); ?>"><i class="fa fa-edit"></i> </a>
                                                                 <?php endif; ?>

                                                                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_delete')): ?>
                                                                    <form action="<?php echo e(route('dashboard.roles.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Are you sure');" style="display: inline-block;">
                                                                        <input type="hidden" name="_method" value="DELETE">
                                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                        <button type="submit" class="btn btn-sm btn-danger" value=""><i class="fa fa-trash"></i></button>
                                                                    </form>
                                                                <?php endif; ?>
                                                               
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                         <div id="pagination"><?php echo e($roles->links()); ?></div>
                                    </div>
                                    <!-- TABLE WRAPPER -->
                                </div>
                                <!-- SECTION WRAPPER -->
                            </div>
                        </div>
                        <!-- ROW-1 CLOSED -->               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/datatable.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
  $('#pagination').on('change', function() {
    var $form = $(this).closest('form');
    //$form.submit();
    $form.find('input[type=submit]').click();
    console.log( $form);
  });
});
</script>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.vertical-menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\popkart\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>